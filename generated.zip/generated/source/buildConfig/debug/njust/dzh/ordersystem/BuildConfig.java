/**
 * Automatically generated file. DO NOT MODIFY
 */
package njust.dzh.ordersystem;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String APPLICATION_ID = "njust.dzh.ordersystem";
  public static final String BUILD_TYPE = "debug";
  public static final int VERSION_CODE = 1;
  public static final String VERSION_NAME = "1.0";
}
