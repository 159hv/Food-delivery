package njust.dzh.ordersystem.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import njust.dzh.ordersystem.Bean.Food;
import njust.dzh.ordersystem.DataBase.FoodDao;
import njust.dzh.ordersystem.R;

public class FoodActivity extends AppCompatActivity {
    public static final String FOOD_DATA = "food_data";
    private FloatingActionButton fab;
    private FoodDao foodDao;
    private Food food;
    private RadioGroup sizeRadioGroup;
    private String selectedSize;
    private String selectedPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);
        initView();
    }

    private void initView() {
        foodDao = new FoodDao(this);
        Intent intent = getIntent();
        food = (Food)intent.getSerializableExtra(FOOD_DATA);
        String foodName = food.getName();
        int foodImageId = food.getImageId();
        String foodComment = food.getComment();
        Toolbar toolbar = findViewById(R.id.toolbar);
        CollapsingToolbarLayout collapsingToolbar = findViewById(R.id.collapsing_toolbar);
        ImageView foodImageView = findViewById(R.id.food_image_view);
        TextView foodContentText = findViewById(R.id.food_content_text);
        sizeRadioGroup = findViewById(R.id.size_radio_group);
        fab = findViewById(R.id.fab);

        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        collapsingToolbar.setTitle(foodName);
        Glide.with(this).load(foodImageId).into(foodImageView);
        String foodContent = generateFoodContent(foodComment);
        foodContentText.setText(foodContent);

        initSizeRadioGroup();

        fab.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if (selectedSize == null) {
                    Toast.makeText(FoodActivity.this, "请选择规格！", Toast.LENGTH_SHORT).show();
                    return;
                }
                foodDao.openDB();
                foodDao.addFood(food, selectedSize, selectedPrice);
                Toast.makeText(FoodActivity.this, "成功将"+foodName+"("+selectedSize+")加入购物车！", Toast.LENGTH_SHORT).show();
                foodDao.closeDB();
            }
        });
    }

    private void initSizeRadioGroup() {
        String[] sizes = food.getSizes();
        String[] prices = food.getSizePrices();

        if (sizes == null || prices == null || sizes.length == 0) {
            sizes = new String[]{"标准"};
            prices = new String[]{food.getPrice()};
        }

        for (int i = 0; i < sizes.length; i++) {
            RadioButton radioButton = new RadioButton(this);
            radioButton.setText(sizes[i] + " - " + prices[i] + "元");
            radioButton.setTextSize(18);
            radioButton.setPadding(20, 10, 20, 10);
            final int index = i;
            radioButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectedSize = sizes[index];
                    selectedPrice = prices[index];
                }
            });
            sizeRadioGroup.addView(radioButton);
            if (i == 0) {
                radioButton.setChecked(true);
                selectedSize = sizes[0];
                selectedPrice = prices[0];
            }
        }
    }

    // 生成食物内容
    private String generateFoodContent(String foodComment) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < 100; i++) {
            stringBuilder.append(foodComment);
        }
        return stringBuilder.toString();
    }
    // 菜单栏返回按钮的点击事件
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}