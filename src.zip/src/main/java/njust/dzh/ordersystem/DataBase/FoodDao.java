package njust.dzh.ordersystem.DataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import java.util.ArrayList;
import java.util.List;

import njust.dzh.ordersystem.Bean.Cart;
import njust.dzh.ordersystem.Bean.Food;

public class FoodDao {
    private Context context;
    private DataBaseHelper dataBaseHelper;
    private SQLiteDatabase database;

    public FoodDao (Context context) {
        this.context = context;
    }

    // 打开数据库
    public void openDB() throws SQLiteException {
        dataBaseHelper = new DataBaseHelper(context);
        try {
            database = dataBaseHelper.getWritableDatabase();
        } catch (SQLiteException e) {
            database = dataBaseHelper.getReadableDatabase();
        }
    }

    // 关闭数据库
    public void closeDB() {
        if(database != null) {
            database.close();
            database = null;
        }
    }

    // 添加食物到购物车
    public void addFood(Food food, String size, String sizePrice) {
        if (!queryFood(food.getName(), size)) {
            ContentValues values = new ContentValues();
            values.put("name", food.getName());
            values.put("imageId", food.getImageId());
            values.put("price", sizePrice);
            values.put("num", 1);
            values.put("size", size);
            database.insert("Cart", null, values);
        } else {
            ContentValues values = new ContentValues();
            int num = queryFoodNum(food.getName(), size);
            if (num != 0) {
                values.put("num", num + 1);
                double singlePrice = Double.parseDouble(sizePrice);
                double price = singlePrice * (num + 1);
                values.put("price", price);
                database.update("Cart", values, "name = ? and size = ?", new String[] {food.getName(), size});
            }
        }
    }

    public boolean queryFood(String name, String size) {
        Cursor cursor = database.query("Cart", null, null, null, null, null,null);
        if (cursor.moveToFirst()) {
            do {
                String foodName = cursor.getString(cursor.getColumnIndex("name"));
                String foodSize = cursor.getString(cursor.getColumnIndex("size"));
                if (foodName.equals(name) && foodSize.equals(size)) {
                    return true;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return false;
    }

    public int queryFoodNum(String name, String size) {
        Cursor cursor = database.query("Cart", null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                String foodName = cursor.getString(cursor.getColumnIndex("name"));
                String foodSize = cursor.getString(cursor.getColumnIndex("size"));
                int foodNum = cursor.getInt(cursor.getColumnIndex("num"));
                if (foodName.equals(name) && foodSize.equals(size)) {
                    return foodNum;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return 0;
    }

}
